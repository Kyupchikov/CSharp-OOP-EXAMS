﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Equipment
{
    public class BoxingGloves : Equipment
    {
        // Weights 227 grams and price of 120.
        public BoxingGloves()
            : base(227, 120)
        {

        }
    }
}
