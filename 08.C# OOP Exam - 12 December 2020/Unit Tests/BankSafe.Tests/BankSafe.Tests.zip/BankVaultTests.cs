using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace BankSafe.Tests
{
    public class BankVaultTests
    {

        private BankVault BankVault;
        //  private readonly Dictionary<string, Item> vaultCells;


        [SetUp]
        public void Setup()
        {
            //this.vaultCells.Add("A1", null);             
            //this.vaultCells.Add("A2", null);             
            //this.vaultCells.Add("A3", null);             
            //this.vaultCells.Add("A4", null);             
            //this.vaultCells.Add("B1", null);             
            //this.vaultCells.Add("B2", null);             
            //this.vaultCells.Add("B3", null);             
            //this.vaultCells.Add("B4", null);             
            //this.vaultCells.Add("C1", null);             
            //this.vaultCells.Add("C2", null);             
            //this.vaultCells.Add("C3", null);             
            //this.vaultCells.Add("C4", null);             



            this.BankVault = new BankVault();
        }

        [Test]
        public void AddItemCheck()
        {
            Item item = new Item("aa", "bb");
            Assert.AreEqual(12, this.BankVault.VaultCells.Count);
            Assert.Throws<ArgumentException>(() => this.BankVault.AddItem("A11", new Item("aa", "bb")));
            this.BankVault.AddItem("A1", item);
            Assert.AreEqual("Remove item:bb successfully!", this.BankVault.RemoveItem("A1", item));
            Assert.AreEqual("Item:bba saved successfully!", this.BankVault.AddItem("A4", new Item("aab", "bba")));
            this.BankVault.AddItem("A1", item);
            Assert.Throws<ArgumentException>(() => this.BankVault.AddItem("A1", new Item("aaa", "bbb")));
            Assert.Throws<InvalidOperationException>(() => this.BankVault.AddItem("A2", new Item("aa", "bb")));
            Assert.Throws<ArgumentException>(() => this.BankVault.RemoveItem("A1", new Item("aaa", "bbb")));
            Assert.Throws<ArgumentException>(() => this.BankVault.RemoveItem("A11", new Item("aaabbb", "bbb")));
        }

        [Test]
        public void RemoveItemCheck()
        {
        }
    }
}